
package Registro;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;

@WebService(serviceName = "RegistroCivilWS")
public class RegistroCivilWS {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "Registro")
    public ArrayList DatosRegistros(@WebParam(name = "patente") String Patente)
    {
     String control_excep="";
     int contador = 0;
     ArrayList nombre = new ArrayList();
    try 
        {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        }
    catch(Exception e)
	{ 
            control_excep="1";
        }  
     
    try 
	{
            String ulr ="";
            ulr = "jdbc:sqlserver://localhost:1433;database=REGISTROCIVIL;user=sa;password=123456";
            Connection conn = DriverManager.getConnection(ulr);
            if (conn != null)
            {
                String strProcedure="{call SeleccionaDatosRegistroCivil(?)}";
                CallableStatement cstmt=conn.prepareCall(strProcedure);
                {
                    cstmt.setString(1,Patente);
                }
                cstmt.execute();
                ResultSet rst = cstmt.getResultSet();	
                while(rst.next())
		{											
		contador = contador + 1;
                nombre.add(rst.getString(1));
                nombre.add(rst.getString(2));
                nombre.add(rst.getString(3));
                nombre.add(rst.getString(4));
                nombre.add(rst.getString(5));
                }
            }
        }
    catch(Exception e)
        {						
            control_excep="2";
        }
        return nombre;
    }
}
